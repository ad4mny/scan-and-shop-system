-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jan 02, 2022 at 06:22 PM
-- Server version: 8.0.26
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `snssdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartData`
--

CREATE TABLE `cartData` (
  `id` int NOT NULL,
  `cartID` text COLLATE utf8mb4_general_ci,
  `itemID` int DEFAULT NULL,
  `cartQuantity` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cartData`
--

INSERT INTO `cartData` (`id`, `cartID`, `itemID`, `cartQuantity`) VALUES
(1, '61d1e7868ea49', 3, 1),
(2, '61d1e85e11e4d', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `itemData`
--

CREATE TABLE `itemData` (
  `itemID` int NOT NULL,
  `itemName` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `itemPrice` float DEFAULT NULL,
  `itemImg` varchar(500) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `itemStatus` text COLLATE utf8mb4_general_ci,
  `itemDesc` text COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `itemData`
--

INSERT INTO `itemData` (`itemID`, `itemName`, `itemPrice`, `itemImg`, `itemStatus`, `itemDesc`) VALUES
(1, 'Dairy Milk (Chocolate) 250ml', 2.1, NULL, 'Available', 'Susu dairy milk campuran alsi'),
(2, 'Kerepek Ketam Bakar 250g', 11.9, NULL, 'Available', 'Kerepek ketam bakar daripada timur tengah australia'),
(3, 'Sayur Sawi (Packed) 200g', 1.5, NULL, 'Unavailable', 'Sayur sawi dari marikh jauh ke tengah'),
(4, 'Lexus Biscuit (8 Packet)', 5.6, NULL, 'Available', 'Lexus biskut makanan student marhen');

-- --------------------------------------------------------

--
-- Table structure for table `paymentData`
--

CREATE TABLE `paymentData` (
  `paymentID` int NOT NULL,
  `customerID` text COLLATE utf8mb4_general_ci,
  `cartID` text COLLATE utf8mb4_general_ci,
  `paymentTotal` float DEFAULT NULL,
  `paymentStatus` text COLLATE utf8mb4_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `paymentData`
--

INSERT INTO `paymentData` (`paymentID`, `customerID`, `cartID`, `paymentTotal`, `paymentStatus`) VALUES
(1, '2201021745042802', '61d1e7868ea49', 1.65, 'Success'),
(2, '2201021745042802', '61d1e85e11e4d', 1.65, 'Success');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartData`
--
ALTER TABLE `cartData`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `itemData`
--
ALTER TABLE `itemData`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `paymentData`
--
ALTER TABLE `paymentData`
  ADD PRIMARY KEY (`paymentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cartData`
--
ALTER TABLE `cartData`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `itemData`
--
ALTER TABLE `itemData`
  MODIFY `itemID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `paymentData`
--
ALTER TABLE `paymentData`
  MODIFY `paymentID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
